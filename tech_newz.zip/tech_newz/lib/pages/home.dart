import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tech_newz/backend/function.dart';
import 'package:tech_newz/components/newsbox.dart';
import 'package:tech_newz/utils/colors.dart';
import 'package:tech_newz/utils/constants.dart';

class Home extends StatefulWidget {
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late Future<List> news;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    news = fetchnews();
  }
  @override
  Widget build(BuildContext context) {
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppColor.black,
      appBar: AppBar(
        title: Text("Tech News",),
      ),
      body: Column(
        children: [
          SearchBar(),
          Expanded(
            child: Container(
              width: w,
              child: FutureBuilder(
                  future: news,
                  builder: (context, snapshot) {
                    if(snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                          return NewsBox(
                              imageurl: snapshot.data![index]['urlToImage'] != null
                                          ? snapshot.data![index]['urlToImage']
                                          : Constants.imageurl,
                              title: snapshot.data![index]['title'],
                              time: snapshot.data![index]['publishedAt'],
                              description: snapshot.data![index]['description'].toString(),
                              url: snapshot.data![index]['url']);
                          });
                    } else if(snapshot.hasError) {
                      return Text("${snapshot.error}");
                    } return Center(
                      child: CircularProgressIndicator(
                        color: AppColor.primary,
                      ),
                    );
                  }),
            ),
          ),
        ],
      ),
    );
  }
}