class Constants {
  static String imageurl = "";

}