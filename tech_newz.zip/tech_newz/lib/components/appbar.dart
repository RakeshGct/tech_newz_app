import 'package:flutter/cupertino.dart';

class appbar extends StatelessWidget implements PreferredSizeWidget {
  appbar(

      );
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => throw UnimplementedError();


}