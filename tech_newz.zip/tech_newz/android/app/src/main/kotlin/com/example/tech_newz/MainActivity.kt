package com.example.tech_newz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
